import sys, os
script, fastafolder, codemlprefix, modelcodemldoc, outfolder = sys.argv
modelcodeml = open(modelcodemldoc,'r')
fastalist = os.listdir(fastafolder)
for fastadoc in fastalist:
    ogname = fastadoc.split('.')[0]
    os.system("mkdir "+codemlprefix+'/'+ogname)
    thisfile = open(codemlprefix+'/'+ogname+'/'+fastadoc+".ctl", 'w')
    seqfileline = "     seqfile = {fastapre}/{fastadoc}\n".format(fastapre = fastafolder, fastadoc = fastadoc)
    outfileline = "      outfile = {outfolder}/{fastadoc}\n".format(outfolder = outfolder, fastadoc = fastadoc)
    for line in modelcodeml:
        if "seqfile" in line:
            thisfile.write(seqfileline)
        elif "outfile" in line:
            thisfile.write(outfileline)
        else:
            thisfile.write(line)
    thisfile.close()
    modelcodeml.seek(0)
modelcodeml.close()