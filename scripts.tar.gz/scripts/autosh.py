from fileinput import filename
import sys, os
script, inputfolder, outprefix = sys.argv
inputlist = os.listdir(inputfolder)
cnt = 0
cnt2 = 0
thisfile = open(outprefix+"/task"+str(cnt2)+".sh", 'w')
thisfile.write('#!/bin/sh\n')
for foldername in inputlist:
    newfilelist = os.listdir(inputfolder+'/'+foldername)
    newfilename = newfilelist[0]
    cdcmd = "cd {inputfolder}/{foldername}".format(inputfolder = inputfolder, foldername = foldername)
    thisfile.write(cdcmd+'\n')
    command = "/mnt/huangzijian/Banyuetan/paml4.9j/bin/codeml {newfilename}".format(newfilename = newfilename)
    thisfile.write(command+'\n')
    cnt += 1
    if cnt > 20:
        cnt2 += 1
        cnt = 0
        thisfile.close()
        thisfile = open(outprefix+"/task"+str(cnt2)+".sh", 'w')
        thisfile.write('#!/bin/sh\n')
thisfile.close()