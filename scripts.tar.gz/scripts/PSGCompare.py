import sys, os, re

def findPSG(findtbl):
    for line in findtbl:
        if "lnL" in line:
            pat = r'-\d+\.\d+|\d+'
            numlist = re.findall(pat,line)
            mynum = numlist[2]
            return float(mynum)

script, Zeromdfolder, Altmdfolder, outputdoc = sys.argv
outfile = open(outputdoc,'w')
zeromdlist = os.listdir(Zeromdfolder)
altmdlist = os.listdir(Altmdfolder)
for ogname in zeromdlist:
    zerotbl = open(Zeromdfolder+'/'+ogname,'r')
    alttbl = open(Altmdfolder+'/'+ogname,'r')
    zerolnL = findPSG(zerotbl)
    altlnL = findPSG(alttbl)
    try:
        altcom = altlnL - zerolnL
    except:
        continue
    if altcom < 0:
        # outfile.write(ogname+'\t'+str(zerolnL)+'\t' + str(altlnL)+'\t' + str(altcom)+'\t' + chires+'\n')
        continue
    altcom2 = 2*altcom
    chires = os.popen("/mnt/huangzijian/Banyuetan/paml4.9j/bin/chi2 1 "+str(altcom2)).read().strip('\n')
    probpat = r'prob = (.*?) = '
    prob = re.findall(probpat, chires)[0]
    prob = float(prob)/2
    if prob > 0.05:
        zerotbl.close()
        alttbl.close()
        continue
    print(prob)
    outfile.write(ogname+'\t'+str(zerolnL)+'\t' + str(altlnL)+'\t' + str(altcom)+'\t' + str(prob)+'\n')
    zerotbl.close()
    alttbl.close()
outfile.close()