# from Bio import SeqIO
# import sys
# script, fastadoc, outdoc = sys.argv


# records = SeqIO.parse(fastadoc, "fasta")
# count = SeqIO.write(records, outdoc, "phylip")
# print("Converted %i records" % count)
import sys
script, fastadoc, outdoc = sys.argv

def fasta_to_phy(fasta_file, phy_file):
    seq_names = []
    sequences = []
    with open(fasta_file, "r") as f_in:
        for line in f_in:
            line = line.strip()
            if line.startswith(">"):
                seq_name = line[1:]
                seq_names.append(seq_name)
                sequences.append("")
            else:
                sequences[-1] += line

    with open(phy_file, "w") as f_out:
        f_out.write(f"{len(seq_names)}  {len(sequences[0])}\n")
        for i in range(len(seq_names)):
            f_out.write(f"{seq_names[i]}  {sequences[i]}\n")

    print(f"Successfully converted {fasta_file} to {phy_file}.")

fasta_file = fastadoc  # 输入的FASTA文件名
phy_file = outdoc  # 输出的PHYLIP文件名

fasta_to_phy(fasta_file, phy_file)
