import sys, os

scripts, foldername, outfolder = sys.argv

grouplist = []
for filenames in os.listdir(foldername):
    grouplist.append(filenames.split(".")[0])
for groups in grouplist:
    try:
        groupmafft = open(foldername+"/"+groups+'.pal2.res-gb','r')
    except:
        continue
    groupdic = {}
    for line in groupmafft:
        if line[0] == '>':
            spename = line[1:-1]
            groupdic[spename] = ''
        else:
            addseq = line.replace(' ','')
            addseq = addseq.strip('\n')
            groupdic[spename] += addseq
    groupmafft.close()
    newmafft = open(outfolder+'/'+groups+'.pal2.selected.fasta','w')
    for key, value in groupdic.items():
        newmafft.write(">{key}\n{value}\n".format(key = key, value = value))
    newmafft.close()
