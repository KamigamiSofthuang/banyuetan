import sys
script, namedoc, fastadoc, outdoc = sys.argv
fastatbl = open(fastadoc, 'r')
outtbl = open(outdoc, 'w')
nametbl = open(namedoc, 'r')
namedir = {}
for line in nametbl:
    linelist = line.strip().split()
    namedir[linelist[0]] = linelist[1]
for line in fastatbl:
    if line[0] == '>':
        linename = line[1:-1]
        newname = namedir[linename]
        outtbl.write('>'+newname+'\n')
    else:
        outtbl.write(line)
outtbl.close()
nametbl.close()
fastatbl.close()