# Step1 the ortholog group
mkdir OrthofinderWork
mkdir OrthofinderWork/Database

cd OrthofinderWork
orthofinder -f Database -M msa -S diamond -t 16 -a 16
# here we get 7103 single copies
cd ..
# Step2 ready for the sequence
mkdir PrepareSeq
mkdir PrepareSeq/Data
mkdir PrepareSeq/PepDir
mkdir PrepareSeq/GeneAlign
mkdir PrepareSeq/PalWork
mkdir PrepareSeq/Gblocks
mkdir PrepareSeq/SelectedData
cd PrepareSeq
# Write a spelist
cp ../others/spelist ./
python ../scripts/cpdata.py spelist ../OrthoRes/Orthogroups/Orthogroups_SingleCopyOrthologues.txt ../OrthoRes/Single_Copy_Orthologue_Sequences ../Genome Data
cp Data/*.pep* PepDir

i=0
for files in `ls PepDir`
do
    nohup mafft --quiet Data/${files} > GeneAlign/${files} &
    let i++
    if [[ $i -gt 100 ]]
    then
    i=0
    wait
    fi
done

i=0
for files in `ls GeneAlign`
do
    array=(${files//./ })
    cdsfile=${array[0]}.cds.fasta
    nohup pal2nal.pl GeneAlign/${files} Data/${cdsfile} -output fasta > PalWork/${array[0]}.pal2.res &
    let i++
    if [[ $i -gt 100 ]]
    then
    i=0
    wait
    fi
done

i=0
for files in `ls PalWork/*.res`
do
    nohup Gblocks $files -t=c -b4=5 &
    let i++
    if [[ $i -gt 100 ]]
    then
    i=0
    wait
    fi
done
mv PalWork/*-gb Gblocks/
python ../scripts/ChangeSeq.py Gblocks SelectedData
cd ..
# Step3 Use PAML
tar xf paml4.9j.tgz
cd paml4.9j
rm bin/*.exe
cd src
make -f Makefile
ls -lF
rm *.o
mv baseml basemlg codeml pamp evolver yn00 chi2 ../bin
cd ..
ls -lF bin
bin/baseml
bin/codeml
bin/evolver
cd ..

mkdir PAMLPSGs
mkdir PAMLPSGs/M1
mkdir PAMLPSGs/M0
mkdir PAMLPSGs/M1sh
mkdir PAMLPSGs/M0sh
mkdir PAMLPSGs/PSGRes
mkdir PAMLPSGs/PSGRes/M1
mkdir PAMLPSGs/PSGRes/M0
cp -r PrepareSeq/SelectedData PAMLPSGs
cd PAMLPSGs
cp ../OrthoRes/Species_Tree/SpeciesTree_rooted.txt ./humantree.Treefile
cp ../paml4.9j/codeml.ctl ./codeml0.ctl
cp ../paml4.9j/codeml.ctl ./codeml1.ctl
# change treefile, fixomega, Nssitemodel, noisy verbose = 0, seqtype = 1
# change omega=1.2
mkdir PhySeq

i=0
for files in `ls SelectedData`
do
nohup python ../scripts/fasta2phy.py SelectedData/${files} PhySeq/${files} &
    let i++
    if [[ $i -gt 100 ]]
    then
    i=0
    wait
    fi
done

mydir=`pwd`
python ../scripts/autocodeml.py $mydir/PhySeq $mydir/M0 codeml0.ctl $mydir/PSGRes/M0
python ../scripts/autocodeml.py $mydir/PhySeq $mydir/M1 codeml1.ctl $mydir/PSGRes/M1

python ../scripts/autosh.py $mydir/M0 $mydir/M0sh
python ../scripts/autosh.py $mydir/M1 $mydir/M1sh

for files in `ls M0sh`
do
nohup sh M0sh/$files &
done
for files in `ls M1sh`
do
nohup sh M1sh/$files &
done

cd ..
# Step4 Use Hyphy
mkdir HyphyPSGs
mkdir HyphyPSGs/HyphyResult
cp -r PrepareSeq/SelectedData HyphyPSGs
cp PAMLPSGs/humantree.Treefile HyphyPSGs # change 1 to test
cd HyphyPSGs
conda install -c bioconda hyphy
hyphy absrel
for files in `ls SelectedData`
do
hyphy absrel --alignment SelectedData/${files} --tree humantree.Treefile CPU=30 --pvalue 0.05 --branches test > HyphyResult/${files}.out
done

# Step5 
cd ../PAMLPSGs
python ../scripts/PSGCompare.py PSGRes/M0 PSGRes/M1 PSGRes/Results



 