import sys, os
script, spedoc, scdoc, pepfolder, genomefolder, outfolder = sys.argv
spelist = []
spetbl = open(spedoc, 'r')
sctbl = open(scdoc,'r')
sclist = []
for line in sctbl:
    sclist.append(line.strip())
sctbl.close()
for line in spetbl:
    spename = line.strip()
    spelist.append(spename)
spetbl.close()
genetospedir = {}
genetoseqdir = {}
for spename in spelist:
    spegenometbl = open(genomefolder+'/'+spename+'.cds.fasta')
    for line in spegenometbl:
        if line[0] == '>':
            genename = line[1:-1]
            genetospedir[genename] = spename
        else:
            genetoseqdir[genename] = line.strip()
    spegenometbl.close()
cnt = 0
for pepname in os.listdir(pepfolder):
    ogname = pepname.split('.')[0]
    if ogname not in sclist:
        continue
    peptbl = open(pepfolder+'/'+pepname,'r')
    outpep = open(outfolder+'/'+ogname+'.pep.fasta','w')
    outcds = open(outfolder+'/'+ogname+'.cds.fasta','w')
    for line in peptbl:
        if line[0] == '>':
            linename = line[1:-1]
            outname = genetospedir[linename]
            outpep.write('>'+outname+'\n')
            outcds.write('>'+outname+'\n')
        else:
            outpep.write(line)
            outcds.write(genetoseqdir[linename]+'\n')
    outpep.close()
    outcds.close()
    peptbl.close()
    print(pepname)
    cnt += 1
    # if cnt >= 500:
    #     break
        
    